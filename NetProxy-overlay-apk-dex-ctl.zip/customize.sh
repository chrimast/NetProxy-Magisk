#!/system/bin/sh
#######################################
# 文件: customize.sh
# 功能: 覆盖已安装 NetProxy 的管理器 APK、DEX 与 bin/netproxyctl；不改内核与开机脚本。
# 用法: KernelSU/Magisk 本地安装本 zip；须已安装官方 id=netproxy 模块。
# 依赖: 管理器 ui_print/abort、unzip、pm。
#######################################

SKIPUNZIP=1
umask 022
readonly MODULE_ID=netproxy
readonly MANAGER_PACKAGE=com.fanjv.netproxy
LIVE_DIR=/data/adb/modules/netproxy
OVERLAY_LIVE=/data/adb/modules/netproxy-overlay
OVERLAY_UPDATE=/data/adb/modules_update/netproxy-overlay

fail() {
  ui_print "! $1"
  exit 1
}

# 参数: 无。
# 返回: 0=已删除 overlay 目录或本来就不存在。
remove_overlay_dirs() {
  rm -rf "$OVERLAY_LIVE" "$OVERLAY_UPDATE"
}

# 参数: 无。
# 返回: 0=已安排后台清理。
schedule_overlay_cleanup() {
  # 安装器在 customize.sh 返回后仍会写入 overlay 的 module.prop；必须等安装结束再删目录。
  (sleep 8; remove_overlay_dirs) >/dev/null 2>&1 &
}

ui_print "- overlay APK + DEX + ctl onto live $MODULE_ID"

[ -f "$LIVE_DIR/module.prop" ] || fail "未找到 $LIVE_DIR，请先安装官方 NetProxy 模块"
grep -qx "id=$MODULE_ID" "$LIVE_DIR/module.prop" || fail "live 模块 id 不是 $MODULE_ID"
[ -d "$LIVE_DIR/bin" ] || fail "未找到 $LIVE_DIR/bin"

unzip -o "$ZIPFILE" "bin/netproxyctl" "bin/android-platform.dex" "NetProxy.apk" -d "$TMPDIR" >/dev/null
NEW_CTL="$TMPDIR/bin/netproxyctl"
NEW_DEX="$TMPDIR/bin/android-platform.dex"
NEW_APK="$TMPDIR/NetProxy.apk"
[ -s "$NEW_CTL" ] && [ -s "$NEW_DEX" ] && [ -s "$NEW_APK" ] || fail "zip 内缺少 APK、DEX 或 bin/netproxyctl"

if [ -x "$LIVE_DIR/bin/netproxyctl" ]; then
  "$LIVE_DIR/bin/netproxyctl" __internal worker stop --module-dir "$LIVE_DIR" >/dev/null 2>&1 || true
fi
if [ -x "$LIVE_DIR/netproxyctl" ]; then
  "$LIVE_DIR/netproxyctl" service stop >/dev/null 2>&1 || true
fi

cp -f "$LIVE_DIR/bin/netproxyctl" "$LIVE_DIR/bin/netproxyctl.bak-overlay" 2>/dev/null || true
cp -f "$LIVE_DIR/bin/android-platform.dex" "$LIVE_DIR/bin/android-platform.dex.bak-overlay" 2>/dev/null || true
cp -f "$NEW_CTL" "$LIVE_DIR/bin/netproxyctl" || fail "覆盖 bin/netproxyctl 失败"
cp -f "$NEW_DEX" "$LIVE_DIR/bin/android-platform.dex" || fail "覆盖 android-platform.dex 失败"
chmod 755 "$LIVE_DIR/bin/netproxyctl"
chmod 644 "$LIVE_DIR/bin/android-platform.dex"

if pm path "$MANAGER_PACKAGE" >/dev/null 2>&1; then
  pm uninstall --user 0 "$MANAGER_PACKAGE" >/dev/null 2>&1 || true
fi
if pm install -r "$NEW_APK" < /dev/null >/dev/null 2>&1; then
  ui_print "- 管理器安装成功"
else
  ui_print "- 管理器安装失败，模块覆盖已完成；请手动安装 zip 内 NetProxy.apk"
fi

rm -f "$LIVE_DIR/disable" "$LIVE_DIR/remove" "$LIVE_DIR/update" 2>/dev/null || true
schedule_overlay_cleanup

ui_print "- 已覆盖 APK、DEX、ctl，未改内核"
ui_print "- Overlay 不会留在 KernelSU 列表；不要禁用原来的 NetProxy"
ui_print "- 若无法连接模块后台：开关现有 NetProxy 或重启"
